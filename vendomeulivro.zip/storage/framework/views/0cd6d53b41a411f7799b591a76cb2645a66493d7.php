<?php $__env->startSection('content'); ?>


<section class="product-section mb-4">
    <div class="container mt-4">
        <div class="back-link">
            <a href="<?php echo e(url('/busca/'.$data['title'])); ?>"> &lt;&lt; Voltar aos resultados</a>
        </div>
        <div class="row mt-4 product-box">
            <product-image src-image="<?php echo e($data['image']); ?>" alt-image="<?php echo e($data['title']); ?>"></product-image>
            <div class="col-lg-7 col-sm-12 mt-4 mt-xl-0 product-details">
                <h2 class="p-title"><?php echo e($data['title']); ?></h2>
                <p class="book-author">
                    <?php $__currentLoopData = $data['book']['authors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    Autor <a href="#"><?php echo e($name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <p class="book-publishing">
                    Editora: <a href="#"><?php echo e($data['book']['publisher']); ?></a>
                </p>
                <div class="d-flex">
                    <div class="section-price">
                        <h3 class="p-price">R$<?php echo e($data['price']); ?></h3>
                        <h4 class="p-stock">Disponível: <span>Google Livros</span></h4>
                    </div>
                    <div class="section-rating d-flex justify-content-end">
                        <div>
                            <h3 class="p-price text-center">4.5</h3>
                            <h4>
                                <span style="background: rgba(0, 0, 0, 0) linear-gradient(to right, rgb(255, 204, 51) 92.4%, rgb(204, 204, 204) 70%) repeat scroll 0% 0% padding-box text;" aria-hidden="true">★★★★★</span>
                            </h4>
                        </div>
                    </div>
                </div>
                <div class="product-bay">
                    <a class="btn-loja" href="#">Ir à loja</a>
                </div>
                <div class="accordion accordion-area" id="accordionExample">
                    <div class="card">
                        <div class="card-header" id="headingOne">
                            <button class="card-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Informação
                            </button>
                        </div>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                                <?php echo e(Str::limit($data['description'], 100, '...')); ?>

                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header" id="headingTwo">
                            <button class="card-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Histórico de preços
                            </button>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="card-body">
                                oi
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-4 product-info">
                <div class="container">
                    <h2 class="title mb-4">Características</h2>
                    <ul class="list-features">
                        <li class="list-item">
                            <strong>Título do livro</strong>
                            <span><?php echo e($data['title']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>Autor</strong>
                            <span>
                                <?php $__currentLoopData = $data['book']['authors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?>,
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </li>
                        <li class="list-item">
                            <strong>Idioma</strong>
                            <span><?php echo e($data['book']['language']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>Editora</strong>
                            <span><?php echo e($data['book']['publisher']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>Formato</strong>
                            <span><?php echo e($data['book']['type']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>Tipo de narração</strong>
                            <span><?php echo e($data['book']['narration']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>ISBN</strong>
                            <span><?php echo e($data['book']['isbn']); ?></span>
                        </li>
                        <li class="list-item">
                            <strong>Ano de publicação</strong>
                            <span><?php echo e($data['book']['publishedDate']); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-12 mt-4 product-info">
                <div class="container">
                    <h2 class="title mb-4">Descrição</h2>
                    <div class="item-description-text">
                        <p><?php echo e($data['description']); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-4 product-info">
                <product-rating :product="'<?php echo e($data['id']); ?>'"></product-rating>
            </div>
            <div class="col-12 mt-4 product-info">
                <div class="container perguntas">
                    <h2 class="title mb-4">Perguntas e respostas</h2>
                    <p class="subtitle mt-4">Qual informação você precisa?</p>
                    <div class="row">
                        <div class="col-12 mt-3 mt-md-0">
                            <a href="#" class="btn btn-outline-primary">Custo e prazo de envio</a>
                            <a href="#" class="btn btn-outline-primary">Meios de pagamento</a>
                            <a href="#" class="btn btn-outline-primary">Garantia</a>
                            <a href="#" class="btn btn-outline-primary">Devoluções grátis</a>
                        </div>
                    </div>
                    <p class="subtitle mt-4">Ou pergunte ao vendedor</p>
                    <pergunta-vendedor :product="'<?php echo e($data['id']); ?>'"></pergunta-vendedor>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid"></div>
</section>
<modal-avaliacao></modal-avaliacao>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['seo' => $seo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\web\back-end\vendomeulivro\resources\views/pages/product.blade.php ENDPATH**/ ?>