<meta name="language" content="pt-BR" />
<meta name="country" content="BRA" />
<meta name="currency" content="R$" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="robots" content="index, follow" />
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />

<meta name="apple-mobile-web-app-title" content="<?php echo e(config('app.name', 'Vendomeulivo')); ?>" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="#31acb4" />
<meta name="theme-color" content="#31acb4" />

<?php if(isset($seo['title'])): ?>
    <title><?php echo e($seo['title']); ?> | <?php echo e(config('app.name', 'Vendomeulivo')); ?></title>
    <meta property="og:title" content="<?php echo e($seo['title']); ?>">
    <meta name="twitter:title" content="<?php echo e($seo['title']); ?>">
<?php else: ?>
    <title>Compare preços de livros e melhores ofertas e descontos | <?php echo e(config('app.name', 'Vendomeulivo')); ?></title>
    <meta property="og:title" content="Compare preços de livros e melhores ofertas e descontos">
    <meta name="twitter:title" content="Compare preços de livros e melhores ofertas e descontos">
<?php endif; ?>

<?php if(isset($seo['description'])): ?>
    <meta name="description" content="<?php echo e($seo['description']); ?>" />
    <meta property="og:description" content="<?php echo e(Str::limit($seo['description'], 195, '...')); ?>"/>
    <meta name="twitter:description" content="<?php echo e(Str::limit($seo['description'], 195, '...')); ?>">
<?php else: ?>
    <meta name="description" content="No vendomeulivro.com você encontra as melhores ofertas de Livros. Encontre o menor preço nas melhores lojas!" />
    <meta property="og:description" content="No vendomeulivro.com você encontra as melhores ofertas de Livros. Encontre o menor preço nas melhores lojas!"/>
    <meta name="twitter:description" content="No vendomeulivro.com você encontra as melhores ofertas de Livros. Encontre o menor preço nas melhores lojas!">
<?php endif; ?>

<?php if(isset($seo['abstract'])): ?>
    <meta name="abstract" content="<?php echo e($seo['abstract']); ?>" />
<?php else: ?>
    <meta name="abstract" content="Livros, Ebook | vendomeulivro.com" />
<?php endif; ?>
<meta name="author" content="ReinanHS, reinangabriel1520@gmail.com" />
<meta name="copyright" content="vendomeulivo.com" />

<!-- Open Graph Facebook -->
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:site_name" content="Vendo meu livro"/>

<?php if(isset($seo['product']['image'][0])): ?>
<meta property="og:image" content="<?php echo $seo['product']['image'][0]; ?>">
<?php else: ?>
<meta property="og:image" content="<?php echo e(url('/img/www.vendomeulivro.com.png')); ?>">
<?php endif; ?>

<?php if( isset($seo['product']) ): ?>
    <meta property="og:type" content="og:product" />

    <script type="application/ld+json">
        {
          "@context": "https://schema.org/",
          "@type": "Product",
          "name": "<?php echo e($seo['title']); ?>",
          "image": [
            <?php for($i = 0; $i < sizeof($seo['product']['image']); $i++): ?>
            "<?php echo e($seo['product']['image'][$i]); ?>"<?php if($i < sizeof($seo['product']['image']) - 1): ?>, <?php endif; ?>
            <?php endfor; ?>
           ],
          "description": "<?php echo e(Str::limit($seo['description'], 135, '...')); ?>",
          "sku": "<?php echo e($seo['product']['id']); ?>",
          "mpn": "925872",
          "brand": {
            "@type": "Brand",
            "name": "<?php echo e($seo['product']['editora']); ?>"
          },
          "review": {
            "@type": "Review",
            "reviewRating": {
              "@type": "Rating",
              "ratingValue": "<?php echo e($seo['product']['review']['rating']); ?>",
              "bestRating": "5"
            },
            "author": {
              "@type": "Person",
              "name": "<?php echo e($seo['product']['review']['name']); ?>"
            },
            "headline": "Bem legal",
            "reviewBody": "<?php echo e($seo['product']['review']['body']); ?>",
            "datePublished": "<?php echo e($seo['product']['review']['date']); ?>"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.4",
            "reviewCount": "89"
          },
          "offers": {
            "@type": "AggregateOffer",
            "offerCount": "5",
            "lowPrice": "<?php echo e($seo['product']['offers']['lowPrice']); ?>",
            "highPrice": "<?php echo e($seo['product']['offers']['highPrice']); ?>",
            "priceCurrency": "BRL"
          }
        }
    </script>
<?php else: ?>
    <meta property="og:type" content="website">
<?php endif; ?>

<!-- Twitter -->
<meta name="twitter:url" content="<?php echo e(url()->current()); ?>">
<meta name="twitter:card" content="summary">

<?php if(isset($seo['product']['image'][0]) ): ?>
<meta name="twitter:image" content="<?php echo $seo['product']['image'][0]; ?>">
<?php else: ?>
<meta name="twitter:image" content="<?php echo e(url('/img/www.vendomeulivro.com.png')); ?>">
<?php endif; ?>

<meta name="twitter:creator" content="@ReinanGabriel9">


<?php if(isset($seo['keywords'])): ?>
    <meta name="keywords" content="<?php $__currentLoopData = $seo['keywords']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keywords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($keywords); ?>,<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> vendo meu livro"/>
<?php else: ?>
    <meta name="keywords" content="vendomeulivro"/>
<?php endif; ?>

<?php if(url()->current() == url('/')): ?>
<script type="application/ld+json">
    {
    "@context": "http://schema.org",
    "@type": "WebSite",
    "name": "Vendo meu livro",
    "url": "https://www.vendomeulivro.com/",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.vendomeulivro.com/busca/{search_term_string}",
        "query-input": "required name=search_term_string"
        }
    }
</script>

<script type="application/ld+json">
    {
    "@context": "http://schema.org",
    "@type": "Organization",
    "name": "Vendo meu livro",
    "url": "https://www.vendomeulivro.com/",
    "logo":"https://vendomeulivro.com/img/logos/logo-site-vendomeulivro-top.png",
    "contactPoint":
    [{
        "@type" : "ContactPoint",
        "telephone" : "55 (79) 99931-3136",
        "url" : "https://www.vendomeulivro.com/central-de-atendimento",
        "contactType" : "customer service"
    }],
    "sameAs" : [
    "https://www.facebook.com/vendomeulivro/",
    "https://twitter.com/vendomeulivro",
    "https://www.youtube.com/user/vendomeulivro",
    "https://www.instagram.com/vendomeulivro/",
    "https://www.linkedin.com/company/vendomeulivro/"
    ]
    }
</script>
<?php endif; ?>

<link rel="shortcut icon" href="<?php echo e(url('/img/logos/favicon.ico')); ?>" />
<link rel="apple-touch-icon" href="<?php echo e(url('/img/logos/60x60-precomposed.png')); ?>" />
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(url('/img/logos/76x76-precomposed.png')); ?>" />
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(url('/img/logos/120x120-precomposed.png')); ?>" />
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(url('/img/logos/152x152-precomposed.png')); ?>" />
<?php /**PATH D:\Projects\web\back-end\vendomeulivro\resources\views/components/seo.blade.php ENDPATH**/ ?>