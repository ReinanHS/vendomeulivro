<?php $__env->startSection('content'); ?>
<search-box q="<?php echo e(str_replace('-', ' ', $url)); ?>"></search-box>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-top'); ?>
<script>history.pushState({}, null, '<?php echo e($url); ?>')</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\web\back-end\vendomeulivro\resources\views/pages/busca.blade.php ENDPATH**/ ?>