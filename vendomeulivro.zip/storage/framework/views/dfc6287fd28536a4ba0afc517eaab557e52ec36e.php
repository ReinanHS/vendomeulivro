<section class="book-list pt-4" style="background: <?php echo e($background ?? 'initial'); ?>;">
    <div class="container-fluid">
        <div class="container mb-2">
            <div class="row">
                <div class="col-12 col-md-9 d-flex justify-content-md-start justify-content-center">
                    <a href="#" class="book-title">
                        <h2><?php echo e($title ?? 'Listagem dos produtos'); ?></h2>
                    </a>
                </div>
                <div class="col-12 col-md-3 d-flex justify-content-end justify-content-center">
                    <a href="#" class="btn btn-veja-mais">Veja mais</a>
                </div>
            </div>
        </div>
        <div class="col-12">
            <category-list :carousel-id="'<?php echo e($item['id']); ?>'">
                <?php if(isset($item['items'])): ?>
                    <?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-cell">
                        <div class="card-container">
                            <div class="card-top placeholdershimmer">
                                <div class="card-image">
                                    <a href="<?php echo e($livro['link']); ?>">
                                        <img src="<?php echo e($livro['image']); ?>" alt="Capa do livro <?php echo e($livro['title']); ?>">
                                        <div class="card-image-effect"></div>
                                    </a>
                                </div>
                                <book-card-action-btn :book="{like: false, id: <?php echo e($livro['id']); ?>, code: '<?php echo e($livro['id']); ?>'}"></book-card-action-btn>
                            </div>
                            <div class="card-body">
                                <a class="card-title" href="<?php echo e($livro['link']); ?>">
                                    <div class="title" title="<?php echo e($livro['title']); ?>">
                                        <p><?php echo e($livro['title']); ?></p>
                                        <div class="text-effect"></div>
                                    </div>
                                </a>
                                <a class="card-author" href="<?php echo e($livro['link']); ?>">
                                    <div class="author" title="<?php echo e($livro['subtitle']); ?>">
                                        <span><?php echo e($livro['subtitle']); ?></span>
                                        <div class="text-effect"></div>
                                    </div>
                                </a>
                            </div>
                            <div class="card-button">
                            <div class="rating-section">
                                <div class="stars-rating">
                                    <div class="stars"></div>
                                </div>
                                <div class="card-price">
                                    <a href="<?php echo e($livro['link']); ?>">R$ <?php echo e($livro['price']); ?></a>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </category-list>
        </div>
    </div>
</section>
<?php /**PATH D:\Projects\web\back-end\vendomeulivro\resources\views/components/book-slide.blade.php ENDPATH**/ ?>