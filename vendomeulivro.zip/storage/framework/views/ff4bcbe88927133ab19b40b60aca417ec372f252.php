<div id="bookCarousel" class="carousel slide carousel-fade" data-ride="carousel">
    <div class="carousel-inner">
        <?php for($i = 0; $i < sizeof($carousels); $i++): ?>
        <div class="carousel-item <?php if($i == 0): ?> active <?php endif; ?> d-flex justify-content-center align-self-center" <?php if(isset($carousels[$i]['background'])): ?> style="background-image: <?php echo e($carousels[$i]['background']); ?>; <?php if(isset($carousels[$i]['background-size'])): ?> background-size: <?php echo e($carousels[$i]['background-size']); ?>;<?php endif; ?>"<?php endif; ?>>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 col-12 d-flex flex-wrap align-self-center">
                        <h4 class="text-md-left text-center"><?php echo e($carousels[$i]['title']); ?></h4>
                        <?php if(isset($carousels[$i]['description'])): ?>
                            <p><?php echo e(Str::limit($carousels[$i]['description'], 135, '...')); ?></p>
                        <?php endif; ?>

                        <?php if(isset($carousels[$i]['link'])): ?>
                            <a href="<?php echo e($carousels[$i]['link']); ?>"><?php echo e($carousels[$i]['link-title'] ?? 'Mais informações'); ?></a>
                        <?php endif; ?>
                        <a href="<?php echo e($carousels[$i]['link-store']); ?>" class="btn btn-comprar">Quero este livro</a>
                    </div>
                    <div class="col-md-5 col-12 order-md-2 order-1 mask">
                        <img src="<?php echo e($carousels[$i]['image']); ?>" class="rounded mx-auto d-block" alt="slide <?php echo e($i); ?>">
                    </div>
                </div>
            </div>
           
        </div>
        <?php endfor; ?>
    </div>
    <a class="carousel-control-prev" href="#bookCarousel" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#bookCarousel" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a>
 </div>
 <!--slide end-->
<?php /**PATH D:\Projects\web\back-end\vendomeulivro\resources\views/components/carousels-book.blade.php ENDPATH**/ ?>